package com.pratica.kotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
